// A renderer adapter exports an async or sync mix({a,b,width,height,t}) -> RGBA8 array.
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const width = 96;
const height = 96;
const cases = [
  { name: 'solid', rows: [39, 40, 41] },
  { name: 'transparent-gap', rows: [39, 41] },
];

function fixture(rows) {
  const image = new Uint8ClampedArray(width * height * 4);
  for (const y of rows) {
    for (let x = 40; x < 44; x++) {
      image.set([160, 75, 50, 255], (width * y + x) * 4);
    }
  }
  return image;
}

function compare(expected, actual) {
  if (!ArrayBuffer.isView(actual) || actual.BYTES_PER_ELEMENT !== 1 ||
      actual.length !== expected.length) throw Error('Adapter must return a native-size RGBA8 array.');
  const result = { cleared: 0, filled: 0, recoloredOrAlphaChanged: 0 };
  for (let offset = 0; offset < actual.length; offset += 4) {
    const before = expected[offset + 3];
    const after = actual[offset + 3];
    if (before && !after) result.cleared++;
    else if (!before && after) result.filled++;
    else if (before && expected.subarray(offset, offset + 4).some((v, i) => v !== actual[offset + i])) {
      result.recoloredOrAlphaChanged++;
    }
  }
  return result;
}

export async function checkMixIdentity(mix) {
  const samples = [];
  for (const { name, rows } of cases) {
    const expected = fixture(rows);
    for (const t of [0, 0.5, 1]) {
      const output = await mix({ a: expected.slice(), b: expected.slice(), width, height, t });
      const differences = compare(expected, output);
      samples.push({ name, t, ...differences, passed: Object.values(differences).every(n => n === 0) });
    }
  }
  return { passed: samples.every(item => item.passed), samples };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  if (process.argv.length !== 3) {
    console.error('Usage: node check-mix-identity.mjs path/to/renderer-adapter.mjs');
    process.exitCode = 2;
  } else {
    const { mix } = await import(pathToFileURL(resolve(process.argv[2])).href);
    const result = await checkMixIdentity(mix);
    console.log(JSON.stringify(result, null, 2));
    process.exitCode = result.passed ? 0 : 1;
  }
}
