"""Compare aligned, native RGBA captures from a renderer using Pillow."""
import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

STAGES = ("source_a", "posed_a", "mixed", "posed_b", "source_b")
LABELS = ("Source A", "A at target pose", "Mixed at target pose",
          "B at target pose", "Source B")


def visible_difference(first, second):
    changed = 0
    cleared = 0
    filled = 0
    for a, b in zip(first.getdata(), second.getdata()):
        if a[3] or b[3]:
            changed += a != b
            cleared += bool(a[3]) and not b[3]
            filled += not a[3] and bool(b[3])
    return {"visible_rgba_changed": changed, "cleared": cleared, "filled": filled}


def make_strip(images, destination):
    width, height = images[0].size
    scale = max(1, min(5, 240 // max(width, height)))
    cell = max(160, width * scale + 16)
    image = Image.new("RGB", (cell * len(images), height * scale + 40), "#ebece4")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    for idx, (label, stage) in enumerate(zip(LABELS, images)):
        x = idx * cell
        draw.text((x + 8, 8), label, fill="#203629", font=font)
        enlarged = stage.resize((width * scale, height * scale), Image.Resampling.NEAREST)
        image.paste(enlarged, (x + (cell - enlarged.width) // 2, 32), enlarged)
    image.save(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in STAGES:
        parser.add_argument("--" + name.replace("_", "-"), type=Path, required=True)
    parser.add_argument("--region", type=int, nargs=4, metavar=("X", "Y", "W", "H"),
                        help="Apply the same native-pixel region to every image.")
    parser.add_argument("--out", required=True, type=Path, help="Output folder for stages.png and metrics.json")
    args = parser.parse_args()
    images = {}
    for name in STAGES:
        with Image.open(getattr(args, name)) as source:
            images[name] = source.convert("RGBA")
    sizes = {im.size for im in images.values()}
    if len(sizes) != 1:
        parser.error("All stages must share a canvas. Restore trim offsets before comparison.")
    size = images["source_a"].size
    if args.region:
        x, y, w, h = args.region
        if min(x, y) < 0 or min(w, h) <= 0 or x + w > size[0] or y + h > size[1]:
            parser.error("Region exceeds the native canvas.")
        images = {key: im.crop((x, y, x + w, y + h)) for key, im in images.items()}
    counts = {key: sum(im.getchannel("A").histogram()[1:]) for key, im in images.items()}
    pairs = [("posed_a", "posed_b"), ("posed_a", "mixed"), ("posed_b", "mixed")]
    metrics = {
        "inputs": {name: str(getattr(args, name)) for name in STAGES},
        "native_size": size, "region_xywh": args.region,
        "visible_pixels": counts,
        "same_pose_differences": {a + "_vs_" + b: visible_difference(images[a], images[b]) for a, b in pairs},
    }
    args.out.mkdir(parents=True, exist_ok=True)
    make_strip(list(images.values()), args.out / "stages.png")
    (args.out / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
