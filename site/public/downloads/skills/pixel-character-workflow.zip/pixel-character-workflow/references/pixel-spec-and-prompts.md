# 像素规格与提示词

[母图规格与提示词](../../pixel-character-master/references/art.md) · [方向与动作提示词](../../pixel-character-spritesheet/references/motion.md)
