# 来源与适配

审阅日期：2026-11-16。本技能为根据项目需求重新组织、编写的流程与提示词；未复制上游脚本、角色素材、色板或示例角色。它不是上游技能的安装副本。

## junyudev/pixel-art

- [核心技能](https://github.com/junyudev/pixel-art/blob/main/skills/pixel-art/SKILL.md)：借鉴按尺寸与任务选路线、明确原生像素产物、保留可编辑源的思路。这里不强制所有资源用字符网格，也不硬编码模型或 CLI。
- [小尺寸指南](https://github.com/junyudev/pixel-art/blob/main/skills/pixel-art/reference/small.md)：借鉴目标网格绘制、原尺寸检查、色板与轮廓可读性。尺寸分界是该仓库的经验建议，不是本项目定律。
- [构造指南](https://github.com/junyudev/pixel-art/blob/main/skills/pixel-art/reference/large.md)：借鉴先定关节与比例、整体轮廓光照、手脸定点修整。动画章节明确尚未充分验证，不能当成熟八方向管线的证据。
- [概念图指南](https://github.com/junyudev/pixel-art/blob/main/skills/pixel-art/reference/imagegen.md)：借鉴参考驱动、目标尺寸可读性、局部修订与转换复查；不沿用其固定块尺寸、固定底色、强制变体数或针对 Eastward 的外观规则。
- [转换工具](https://github.com/junyudev/pixel-art/blob/main/skills/pixel-art/tools/elastic2px.py) 与 [摆放工具](https://github.com/junyudev/pixel-art/blob/main/skills/pixel-art/tools/place.py)：源码用于审查单图流程的边界。每图独立识别网格/合色、按包围盒居中贴底可能造成序列闪动或跳位，这是代码分析得到的风险，未宣称已经做过该工具的动画实验。
- [仓库说明与评测](https://github.com/junyudev/pixel-art)：作者展示静态精灵评测；本项目未独立复现，不将排名、胜率外推到动画和换装。

上游代码许可证与 Eastward 参考素材权利分别处理；需要实际复用时读取具体文件及 LICENSE。研究方法不要求复制其他游戏角色。未来引用或移植代码保留适用许可与署名。

## 多方向动画参考

- [Spine 官方八方向说明](https://esotericsoftware.com/forum/d/12904-best-way-to-do-quotbackquot-and-quotfrontquot-on-the-same-character)：共享骨骼、方向附件、姿势与绑定需要专门制作；这不提供 AI 自动恢复可靠骨骼的保证。
- [Flare 角色美术源](https://github.com/flareteam/flare-game/tree/master/art_src/characters/hero) 与 [流程兼容性讨论](https://github.com/flareteam/flare-game/discussions/984)：参考三维制作、二维输出路线；旧工程与导出流程有兼容和手工步骤，不直接视为现代工具链的一键方案。

## 本项目新增沉淀

跨帧共享原点与色板；保持解剖持剑手；同相位比较参考与重建；分离移动、朝向和步态；用代表动作提前检验换装；真实游戏尺寸和录像验收；自动测试与观感分开；以具体失败决定是否改用烘焙或三维。上述内容来自原型制作反馈与代码审查；在新项目中仍需用代表性小样检验实际效果。
